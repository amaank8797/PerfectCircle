

import SwiftUI

struct ContentView: View {
    @State private var drawingPath = Path()
    @State private var isDrawing = false
    @State private var score: Double? = nil
    @State private var highScore: Double = 0
    @State private var selectedColor: Color = .red
    @State private var lineWidth: CGFloat = 5
    
    var body: some View {
        VStack {
            Spacer()
            Text("Draw a Circle").font(.largeTitle)
            
            HStack {
                Text("Color:")
                ColorPicker("", selection: $selectedColor)
                    .labelsHidden()
                    .frame(width: 50, height: 50)
            }
            .padding()
            
            HStack {
                Text("Line Width:")
                Slider(value: $lineWidth, in: 1...10, step: 1)
                    .padding()
            }
            
            CanvasView(drawingPath: $drawingPath, selectedColor: $selectedColor, lineWidth: $lineWidth, score: $score)
                .aspectRatio(1, contentMode: .fit)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [.red, .blue, .green, .yellow]),
                                startPoint: .topLeading,
                                endPoint: .trailing
                            ),
                            lineWidth: 10
                        )
                )
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            if !isDrawing {
                                drawingPath.move(to: value.location)
                                isDrawing = true
                            } else {
                                drawingPath.addLine(to: value.location)
                                if let newScore = calculateCircleScore(for: drawingPath) {
                                    score = newScore
                                    if newScore > highScore {
                                        highScore = newScore
                                    }
                                }
                            }
                        }
                        .onEnded { _ in
                            isDrawing = false
                            drawingPath = Path() // Clear the canvas after the drawing is complete
                        }
                )
                .padding()
            
            if let score = score {
                Text("Score: \(Int(score))")
                    .font(.title)
                    .padding()
                    .foregroundColor(score > 90 ? .green : (score >= 70 ? Color.orange : .red)) // Conditional text color
                Text("High Score: \(Int(highScore))")
                    .font(.title2)
                    .padding(.top, 5)
            }
            
            Spacer()
        }
        .padding()
    }
    
    func calculateCircleScore(for path: Path) -> Double? {
        guard !path.isEmpty else { return nil }
        
        let rect = path.boundingRect
        let expectedCenter = CGPoint(x: rect.midX, y: rect.midY)
        let expectedRadius = min(rect.width, rect.height) / 2
        
        let sampledPoints = extractPoints(from: path)
        
        var totalDeviation: Double = 0
        for point in sampledPoints {
            let distanceFromCenter = hypot(point.x - expectedCenter.x, point.y - expectedCenter.y)
            let deviation = abs(distanceFromCenter - expectedRadius)
            totalDeviation += deviation
        }
        
        let maxPossibleDeviation = expectedRadius * Double(sampledPoints.count)
        let score = max(0, 100 * (1 - (totalDeviation / maxPossibleDeviation)))
        
        return score
    }
    
    func extractPoints(from path: Path) -> [CGPoint] {
        var points = [CGPoint]()
        
        let cgPath = path.cgPath
        cgPath.applyWithBlock { element in
            let pointsPointer = element.pointee.points
            let pointCount: Int
            
            switch element.pointee.type {
            case .moveToPoint, .addLineToPoint:
                pointCount = 1
            case .addQuadCurveToPoint:
                pointCount = 2
            case .addCurveToPoint:
                pointCount = 3
            case .closeSubpath:
                pointCount = 0
            @unknown default:
                pointCount = 0
            }
            
            for i in 0..<pointCount {
                points.append(pointsPointer[i])
            }
        }
        
        return points
    }
}

struct CanvasView: View {
    @Binding var drawingPath: Path
    @Binding var selectedColor: Color
    @Binding var lineWidth: CGFloat
    @Binding var score: Double?
    
    var body: some View {
        GeometryReader { geometry in
            let center = CGPoint(x: geometry.size.width / 2, y: geometry.size.height / 2)
            
            ZStack {
                Circle()
                    .fill(Color.blue)
                    .frame(width: 10, height: 10)
                    .position(center)
                
                drawingPath.stroke(selectedColor, lineWidth: lineWidth)
            }
            .background(Color(UIColor.systemBackground))
            .contentShape(Rectangle())
        }
    }
}


//import SwiftUI
//
//struct ContentView: View {
//    @State private var drawingPath = Path()
//    @State private var isDrawing = false
//    @State private var score: Double? = nil
//    @State private var highScore: Double = 0
//    @State private var selectedColor: Color = .red
//    @State private var lineWidth: CGFloat = 5
//
//    var body: some View {
//        VStack {
//            Spacer()
//            Text("Draw a Circle").font(.largeTitle)
//
//            HStack {
//                Text("Color:")
//                ColorPicker("", selection: $selectedColor)
//                    .labelsHidden()
//                    .frame(width: 50, height: 50)
//            }
//            .padding()
//
//            HStack {
//                Text("Line Width:")
//                Slider(value: $lineWidth, in: 1...10, step: 1)
//                    .padding()
//            }
//
//            CanvasView(drawingPath: $drawingPath, selectedColor: $selectedColor, lineWidth: $lineWidth, score: $score)
//                .aspectRatio(1, contentMode: .fit)
//                .border(Color.green, width: 5)
//                .gesture(
//                    DragGesture(minimumDistance: 0)
//                        .onChanged { value in
//                            if !isDrawing {
//                                drawingPath.move(to: value.location)
//                                isDrawing = true
//                            } else {
//                                drawingPath.addLine(to: value.location)
//                                if let newScore = calculateCircleScore(for: drawingPath) {
//                                    score = newScore
//                                    if newScore > highScore {
//                                        highScore = newScore
//                                    }
//                                }
//                            }
//                        }
//                        .onEnded { _ in
//                            isDrawing = false
//                            drawingPath = Path() // Clear the canvas after the drawing is complete
//                        }
//                )
//                .padding()
//
//            if let score = score {
//                Text("Score: \(Int(score))")
//                    .font(.title)
//                    .padding()
//                    .foregroundColor(score > 90 ? .green : (score >= 70 ? Color.orange : .red)) // Conditional text color
//                Text("High Score: \(Int(highScore))")
//                    .font(.title2)
//                    .padding(.top, 5)
//            }
//
//            Spacer()
//        }
//        .padding()
//    }
//
//    func calculateCircleScore(for path: Path) -> Double? {
//        guard !path.isEmpty else { return nil }
//
//        let rect = path.boundingRect
//        let expectedCenter = CGPoint(x: rect.midX, y: rect.midY)
//        let expectedRadius = min(rect.width, rect.height) / 2
//
//        let sampledPoints = extractPoints(from: path)
//
//        var totalDeviation: Double = 0
//        for point in sampledPoints {
//            let distanceFromCenter = hypot(point.x - expectedCenter.x, point.y - expectedCenter.y)
//            let deviation = abs(distanceFromCenter - expectedRadius)
//            totalDeviation += deviation
//        }
//
//        let maxPossibleDeviation = expectedRadius * Double(sampledPoints.count)
//        let score = max(0, 100 * (1 - (totalDeviation / maxPossibleDeviation)))
//
//        return score
//    }
//
//    func extractPoints(from path: Path) -> [CGPoint] {
//        var points = [CGPoint]()
//
//        let cgPath = path.cgPath
//        cgPath.applyWithBlock { element in
//            let pointsPointer = element.pointee.points
//            let pointCount: Int
//
//            switch element.pointee.type {
//            case .moveToPoint, .addLineToPoint:
//                pointCount = 1
//            case .addQuadCurveToPoint:
//                pointCount = 2
//            case .addCurveToPoint:
//                pointCount = 3
//            case .closeSubpath:
//                pointCount = 0
//            @unknown default:
//                pointCount = 0
//            }
//
//            for i in 0..<pointCount {
//                points.append(pointsPointer[i])
//            }
//        }
//
//        return points
//    }
//}
//
//struct CanvasView: View {
//    @Binding var drawingPath: Path
//    @Binding var selectedColor: Color
//    @Binding var lineWidth: CGFloat
//    @Binding var score: Double?
//
//    var body: some View {
//        GeometryReader { geometry in
//            let center = CGPoint(x: geometry.size.width / 2, y: geometry.size.height / 2)
//
//            ZStack {
//                Circle()
//                    .fill(Color.blue)
//                    .frame(width: 10, height: 10)
//                    .position(center)
//
//                drawingPath.stroke(selectedColor, lineWidth: lineWidth)
//            }
//            .background(Color(UIColor.systemBackground))
//            .contentShape(Rectangle())
//        }
//    }
//}
//
//
//

